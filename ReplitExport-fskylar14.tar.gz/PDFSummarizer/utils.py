import os
import logging
import fitz  # PyMuPDF
import requests

logger = logging.getLogger(__name__)
GPT_API_KEY = os.getenv("GPT_API_KEY")

def extract_text_from_pdf(file):
    """
    Extract text from a PDF file.
    
    Args:
        file: FileStorage object containing the PDF
        
    Returns:
        str: Extracted text from the PDF, limited to first 4000 characters
    """
    try:
        doc = fitz.open(stream=file.read(), filetype="pdf")
        text = ""
        
        # Log basic PDF info
        logger.debug(f"PDF has {len(doc)} pages")
        
        # Extract text from each page
        for page_num, page in enumerate(doc):
            page_text = page.get_text()
            text += page_text
            logger.debug(f"Extracted {len(page_text)} characters from page {page_num+1}")
        
        # Close the document
        doc.close()
        
        # Trim the text to avoid token limit
        trimmed_text = text[:4000]
        logger.debug(f"Extracted total of {len(text)} characters, trimmed to {len(trimmed_text)}")
        
        return trimmed_text
    except Exception as e:
        logger.exception(f"Error extracting text from PDF: {e}")
        raise

def extract_keywords(text, num_keywords=10):
    """Extract important keywords from text"""
    # Split text into words and filter out common words
    common_words = {"the", "a", "an", "in", "on", "at", "to", "for", "with", "by", "of", "and", "or", "is", "are", "was", "were"}
    words = [word.lower() for word in text.split() if word.lower() not in common_words and len(word) > 3]
    
    # Count word frequencies
    word_counts = {}
    for word in words:
        if word in word_counts:
            word_counts[word] += 1
        else:
            word_counts[word] = 1
    
    # Get top keywords
    sorted_words = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
    keywords = [word for word, count in sorted_words[:num_keywords]]
    return keywords

def get_first_and_last_sentences(text, num_sentences=2):
    """Get first and last few sentences as they often contain important information"""
    sentences = text.replace('\n', ' ').split('.')
    sentences = [s.strip() + '.' for s in sentences if s.strip()]
    
    if len(sentences) <= num_sentences * 2:
        return ' '.join(sentences)
    
    first_part = ' '.join(sentences[:num_sentences])
    last_part = ' '.join(sentences[-num_sentences:])
    return first_part + ' ' + last_part

# Language information dictionary containing prompts and labels
LANGUAGE_INFO = {
    'en': {
        'name': 'English',
        'summarize_prompt': "Summarize this text in 3 sentences:\n\n{text}",
        'keywords_label': "Key topics: ",
        'translate_prompt': "Translate this text to English:\n\n{text}"
    },
    'es': {
        'name': 'Spanish (Español)',
        'summarize_prompt': "Resume este texto en 3 oraciones:\n\n{text}",
        'keywords_label': "Temas clave: ",
        'translate_prompt': "Traduce este texto al español:\n\n{text}"
    },
    'fr': {
        'name': 'French (Français)',
        'summarize_prompt': "Résumez ce texte en 3 phrases:\n\n{text}",
        'keywords_label': "Sujets clés: ",
        'translate_prompt': "Traduisez ce texte en français:\n\n{text}"
    },
    'de': {
        'name': 'German (Deutsch)',
        'summarize_prompt': "Fassen Sie diesen Text in 3 Sätzen zusammen:\n\n{text}",
        'keywords_label': "Hauptthemen: ",
        'translate_prompt': "Übersetzen Sie diesen Text ins Deutsche:\n\n{text}"
    },
    'zh': {
        'name': 'Chinese (中文)',
        'summarize_prompt': "用3句话总结这段文字：\n\n{text}",
        'keywords_label': "关键主题：",
        'translate_prompt': "将此文本翻译成中文：\n\n{text}"
    },
    'ja': {
        'name': 'Japanese (日本語)',
        'summarize_prompt': "このテキストを3つの文で要約してください：\n\n{text}",
        'keywords_label': "主要なトピック：",
        'translate_prompt': "このテキストを日本語に翻訳してください：\n\n{text}"
    },
    'ar': {
        'name': 'Arabic (العربية)',
        'summarize_prompt': "لخص هذا النص في 3 جمل:\n\n{text}",
        'keywords_label': "المواضيع الرئيسية: ",
        'translate_prompt': "ترجم هذا النص إلى اللغة العربية:\n\n{text}"
    },
    'pt': {
        'name': 'Portuguese (Português)',
        'summarize_prompt': "Resuma este texto em 3 frases:\n\n{text}",
        'keywords_label': "Tópicos principais: ",
        'translate_prompt': "Traduza este texto para português:\n\n{text}"
    },
    'ru': {
        'name': 'Russian (Русский)',
        'summarize_prompt': "Обобщите этот текст в 3 предложениях:\n\n{text}",
        'keywords_label': "Ключевые темы: ",
        'translate_prompt': "Переведите этот текст на русский язык:\n\n{text}"
    },
    'hi': {
        'name': 'Hindi (हिन्दी)',
        'summarize_prompt': "इस पाठ को 3 वाक्यों में सारांशित करें:\n\n{text}",
        'keywords_label': "मुख्य विषय: ",
        'translate_prompt': "इस टेक्स्ट का हिंदी में अनुवाद करें:\n\n{text}"
    }
}

# Helper functions to get language-specific information
def get_language_name(language_code):
    return LANGUAGE_INFO.get(language_code, LANGUAGE_INFO['en'])['name']

def get_summarize_prompt(language_code):
    return LANGUAGE_INFO.get(language_code, LANGUAGE_INFO['en'])['summarize_prompt']

def get_keywords_label(language_code):
    return LANGUAGE_INFO.get(language_code, LANGUAGE_INFO['en'])['keywords_label']

def get_translate_prompt(language_code):
    return LANGUAGE_INFO.get(language_code, LANGUAGE_INFO['en'])['translate_prompt']

def summarize_text(text, language='en'):
    """
    Generate a summary of the given text in the specified language.
    
    Args:
        text: The text to summarize
        language: The language code for the summary output
        
    Returns:
        str: Summary of the text in the requested language
    """
    # Default to English if requested language is not supported
    if language not in LANGUAGE_INFO:
        language = 'en'
    
    try:
        if not GPT_API_KEY:
            logger.warning("No API key provided, using fallback summarization method")
            return fallback_summarize(text, language)
            
        headers = {
            "Authorization": f"Bearer {GPT_API_KEY}",
            "Content-Type": "application/json"
        }
        
        # First, generate a summary in English
        english_summary = None
        if language == 'en':
            # If target is English, just summarize directly
            prompt = get_summarize_prompt('en').format(text=text)
            data = {
                "model": "mistralai/mistral-7b-instruct-v0.1",
                "messages": [{
                    "role": "user",
                    "content": prompt
                }]
            }
            
            logger.debug("Generating English summary")
            try:
                response = requests.post(
                    "https://openrouter.ai/api/v1/chat/completions", 
                    json=data, 
                    headers=headers,
                    timeout=10
                )
                
                response.raise_for_status()
                result = response.json()
                
                if "choices" in result and len(result["choices"]) > 0:
                    english_summary = result["choices"][0]["message"]["content"]
                    logger.debug(f"Generated English summary of {len(english_summary)} characters")
                    return english_summary  # Return English summary directly
            except Exception as api_error:
                logger.warning(f"English summary API request failed: {str(api_error)}")
                english_summary = fallback_summarize(text, 'en')  # Generate English summary with fallback
        else:
            # For non-English targets, first generate an English summary
            logger.debug(f"Generating English summary for later translation to {language}")
            english_summary = summarize_text(text, 'en')
        
        # If we have an English summary and target language is not English, translate it
        if english_summary and language != 'en':
            # Use the language-specific translation prompt
            translate_prompt = get_translate_prompt(language).format(text=english_summary)
            
            data = {
                "model": "mistralai/mistral-7b-instruct-v0.1",
                "messages": [{
                    "role": "user",
                    "content": translate_prompt
                }]
            }
            
            logger.debug(f"Translating summary to {language}")
            try:
                response = requests.post(
                    "https://openrouter.ai/api/v1/chat/completions", 
                    json=data, 
                    headers=headers,
                    timeout=10
                )
                
                response.raise_for_status()
                result = response.json()
                
                if "choices" in result and len(result["choices"]) > 0:
                    translated_summary = result["choices"][0]["message"]["content"]
                    logger.debug(f"Translated summary to {language}, {len(translated_summary)} characters")
                    return translated_summary
            except Exception as api_error:
                logger.warning(f"Translation API request failed: {str(api_error)}")
                # Fall back to a simple message in the target language that indicates translation failed
                return f"{get_keywords_label(language)}: Translation failed. Original summary: {english_summary}"
        
        # If we somehow got here without a summary, use fallback
        return fallback_summarize(text, language)
            
    except Exception as e:
        logger.exception(f"Error summarizing text: {e}")
        return fallback_summarize(text, language)

def translate_text(text, target_language):
    """
    Translate text to the target language using OpenRouter API.
    Falls back to original text if translation fails.
    """
    if target_language == 'en':
        return text  # No need to translate if target is English
        
    if not GPT_API_KEY:
        logger.warning("No API key for translation")
        return text
        
    try:
        headers = {
            "Authorization": f"Bearer {GPT_API_KEY}",
            "Content-Type": "application/json"
        }
        
        # Use the language-specific translation prompt
        prompt = get_translate_prompt(target_language).format(text=text)
        
        data = {
            "model": "mistralai/mistral-7b-instruct-v0.1",
            "messages": [{
                "role": "user",
                "content": prompt
            }]
        }
        
        logger.debug(f"Sending translation request to API")
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            json=data,
            headers=headers,
            timeout=10
        )
        
        response.raise_for_status()
        result = response.json()
        
        if "choices" in result and len(result["choices"]) > 0:
            translated_text = result["choices"][0]["message"]["content"]
            logger.debug(f"Successfully translated text to {target_language}")
            return translated_text
    except Exception as e:
        logger.warning(f"Translation failed: {str(e)}")
    
    # Return original text if translation fails
    return text

def fallback_summarize(text, language='en'):
    """Fallback method for summarizing text when API is unavailable"""
    logger.info(f"Using fallback summarization method in {language}")
    
    # Get keywords and important sentences
    keywords = extract_keywords(text, num_keywords=8)
    important_parts = get_first_and_last_sentences(text, num_sentences=2)
    
    # Create a simple summary with language-specific labels
    keyword_label = get_keywords_label(language)
    keyword_text = keyword_label + ", ".join(keywords)
    summary = f"{important_parts}\n\n{keyword_text}"
    
    # Try to translate the summary if language is not English
    if language != 'en':
        return translate_text(summary, language)
    
    return summary
