import os
import logging
import json
import datetime
from flask import Flask, request, render_template, flash, redirect, url_for, session
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from utils import extract_text_from_pdf, summarize_text

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-dev")

# Configure session to be permanent and last for 30 days
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(days=30)

# Ensure the GPT API key is available
GPT_API_KEY = os.getenv("GPT_API_KEY")

# Freemium settings
FREE_USES = 2  # Number of free translations before requiring subscription
TRIAL_DAYS = 14  # Number of days for free trial
if not GPT_API_KEY:
    logger.warning("GPT_API_KEY environment variable not set!")

# Configure upload settings
ALLOWED_EXTENSIONS = {'pdf'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Define supported languages - same language codes used in utils.py
LANGUAGE_INFO = {
    'en': 'English',
    'es': 'Español (Spanish)',
    'fr': 'Français (French)',
    'de': 'Deutsch (German)',
    'zh': '中文 (Chinese)',
    'ja': '日本語 (Japanese)',
    'ar': 'العربية (Arabic)',
    'pt': 'Português (Portuguese)',
    'ru': 'Русский (Russian)',
    'hi': 'हिन्दी (Hindi)'
}

def check_subscription():
    """Check if user has a valid subscription or free trial"""
    # Initialize session if not already set
    if 'usage' not in session:
        session['usage'] = {
            'count': 0
        }
        session.permanent = True
    
    usage = session['usage']
    
    # Check if user has used their free uses (English only)
    if usage['count'] < FREE_USES:
        return True, None
    
    # Check if user has a subscription
    if usage.get('subscribed', False):
        # Only after subscribing, check if user is within their trial period
        if 'trial_start' in usage:
            start_date = datetime.datetime.fromisoformat(usage['trial_start'])
            days_elapsed = (datetime.datetime.now() - start_date).days
            if days_elapsed < TRIAL_DAYS:
                days_remaining = TRIAL_DAYS - days_elapsed
                return True, f"You have {days_remaining} days left in your free trial."
    
    # User needs to subscribe
    return False, "Please subscribe to continue using this service."

@app.route("/subscribe", methods=["GET"])
def subscribe():
    """Show subscription page"""
    return render_template("subscribe.html")

@app.route("/activate_subscription", methods=["POST"])
def activate_subscription():
    """Activate a subscription for testing/demo purposes"""
    if 'usage' not in session:
        session['usage'] = {
            'count': 0
        }
    
    # Set subscription flag and start trial period
    session['usage']['subscribed'] = True
    
    # Only set trial start date when subscription is activated
    session['usage']['trial_start'] = datetime.datetime.now().isoformat()
    
    flash("Subscription activated successfully! Your 14-day free trial has begun.", "success")
    return redirect(url_for('index'))

@app.route("/", methods=["GET", "POST"])
def index():
    """Main route for the application."""
    summary = None
    original_text = None
    error = None
    filename = None
    language = request.args.get('lang', 'en')  # Default to English
    subscription_message = None
    
    # Check if user tries to use non-English language without subscription
    if language != 'en' and 'usage' in session:
        if not session['usage'].get('subscribed', False):
            flash("Non-English languages require a subscription", "warning")
            return redirect(url_for('subscribe'))
    
    # Ensure the language is supported
    if language not in LANGUAGE_INFO:
        language = 'en'
    
    # Get remaining free uses
    remaining_uses = 0
    if 'usage' in session:
        remaining_uses = max(0, FREE_USES - session['usage'].get('count', 0))
    
    if request.method == "POST":
        # Check if the post request has the file part
        if 'pdf' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        
        file = request.files['pdf']
        requested_language = request.form.get('language', 'en')
        
        # If user tries to use non-English language without subscription
        if requested_language != 'en' and 'usage' in session:
            if not session['usage'].get('subscribed', False):
                flash("Non-English languages require a subscription", "warning")
                return redirect(url_for('subscribe'))
        
        language = requested_language
        
        # If user does not select file, browser also submits an empty part without filename
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        
        # Check subscription status or remaining free uses
        has_access, message = check_subscription()
        
        # For any language other than English or if free uses exhausted, redirect to subscription
        if (not has_access) or (language != 'en' and not session['usage'].get('subscribed', False)):
            if message:
                flash(message, "warning")
            return redirect(url_for('subscribe'))
        
        subscription_message = message  # This could be None or a trial expiry message
        
        if file and allowed_file(file.filename):
            try:
                if file.filename:
                    filename = secure_filename(file.filename)
                    logger.debug(f"Processing file: {filename} in {language}")
                    
                    # Extract text from PDF
                    original_text = extract_text_from_pdf(file)
                    if not original_text:
                        flash("Could not extract text from the PDF. The file might be empty or protected.", "warning")
                        return redirect(request.url)
                    
                    # Get summary from API
                    if GPT_API_KEY:
                        # Only increment usage count for English (free tier)
                        if language == 'en' and 'usage' in session and session['usage']['count'] < FREE_USES:
                            summary = summarize_text(original_text, language)
                            
                            # Increment usage count
                            session['usage']['count'] += 1
                            session.modified = True
                            logger.debug(f"Usage count: {session['usage']['count']}")
                        elif session['usage'].get('subscribed', False):
                            # User has subscription
                            summary = summarize_text(original_text, language)
                        else:
                            # Free uses exhausted, redirect to subscription
                            flash("You've used all your free translations", "warning")
                            return redirect(url_for('subscribe'))
                    else:
                        error = "API key not configured. Please set the GPT_API_KEY environment variable."
                        flash(error, "danger")
                else:
                    flash('Invalid filename', 'danger')
                    return redirect(request.url)
            
            except Exception as e:
                error = f"An error occurred: {str(e)}"
                logger.exception("Error processing PDF")
                flash(error, "danger")
        else:
            flash('File type not allowed. Please upload a PDF file.', 'danger')
            return redirect(request.url)
    
    # Get remaining free uses
    remaining_uses = 0
    if 'usage' in session:
        remaining_uses = max(0, FREE_USES - session['usage'].get('count', 0))
    
    # Check if user has an active subscription
    has_subscription = False
    if 'usage' in session:
        has_subscription = session['usage'].get('subscribed', False)
    
    return render_template(
        "index.html", 
        summary=summary, 
        original_text=original_text, 
        error=error,
        filename=filename,
        languages=LANGUAGE_INFO,
        selected_language=language,
        remaining_uses=remaining_uses,
        has_subscription=has_subscription,
        subscription_message=subscription_message
    )

@app.errorhandler(413)
def too_large(e):
    """Handle file too large error."""
    flash(f"File is too large. Maximum size is {MAX_CONTENT_LENGTH // (1024 * 1024)}MB", "danger")
    return redirect(url_for('index'))

@app.errorhandler(500)
def server_error(e):
    """Handle server errors."""
    logger.exception("Server error")
    return render_template("error.html", error=str(e)), 500

# Set max content length
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
