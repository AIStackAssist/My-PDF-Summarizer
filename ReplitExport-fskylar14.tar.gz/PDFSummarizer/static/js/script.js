document.addEventListener('DOMContentLoaded', function() {
    // Handle the form submission
    const form = document.getElementById('upload-form');
    const submitBtn = document.getElementById('submit-btn');
    
    if (form) {
        form.addEventListener('submit', function() {
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...';
        });
    }
    
    // Handle copy buttons
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const text = this.getAttribute('data-text');
            navigator.clipboard.writeText(text).then(() => {
                // Visual feedback
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-check me-1"></i>Copied!';
                this.classList.add('copy-success');
                
                // Reset after 2 seconds
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.classList.remove('copy-success');
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy text: ', err);
                alert('Failed to copy text. Please try again.');
            });
        });
    });
    
    // File validation
    const fileInput = document.getElementById('pdf');
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                // Check file type
                if (!file.type.match('application/pdf')) {
                    alert('Please select a PDF file');
                    this.value = '';
                    return;
                }
                
                // Check file size (16MB max)
                if (file.size > 16 * 1024 * 1024) {
                    alert('File size exceeds 16MB. Please select a smaller file.');
                    this.value = '';
                }
            }
        });
    }
});
